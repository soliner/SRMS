/**
 * 使input type=date显示当前时间
 */

/*$(document).ready(function () {
	        var time = new Date();
	        var day = ("0" + time.getDate()).slice(-2);
	        var month = ("0" + (time.getMonth() + 1)).slice(-2);
	        var today = time.getFullYear()-1 + "-" + (month) + "-" + (day);
	        $('#time1').val(today);
	    })
$(document).ready(function () {
    	        var time = new Date();
    	        var day = ("0" + time.getDate()).slice(-2);
    	        var month = ("0" + (time.getMonth() + 1)).slice(-2);
    	        var today = time.getFullYear() + "-" + (month) + "-" + (day);
    	        $('#time2').val(today);
    	    })*/
$(function(){
	$("#time1").datepick({dateFormat:"yy-mm-dd"});
	$("#time2").datepick({dateFormat:"yy-mm-dd"});
		});    	